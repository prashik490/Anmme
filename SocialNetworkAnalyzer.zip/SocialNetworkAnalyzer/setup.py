#!/usr/bin/env python
"""
AniStream Setup Script
======================
This script handles initial setup and maintenance tasks for the AniStream application.
"""

import argparse
import os
import sys

def setup_environment():
    """Setup environment variables if not already set"""
    print("Setting up environment variables...")
    if not os.environ.get("SESSION_SECRET"):
        os.environ["SESSION_SECRET"] = "anistream_development_secret_key"
        print("- Set SESSION_SECRET")
    
    if not os.environ.get("DATABASE_URL"):
        db_path = os.path.join(os.getcwd(), "instance", "anistream.db")
        os.environ["DATABASE_URL"] = f"sqlite:///{db_path}"
        print(f"- Set DATABASE_URL to {os.environ['DATABASE_URL']}")
    
    print("Environment setup complete.")

def init_database():
    """Initialize or reset the database"""
    from app import db, app
    
    with app.app_context():
        print("Initializing database...")
        db.create_all()
        print("Database initialized.")

def add_admin():
    """Add admin user"""
    import importlib.util
    
    # Import the admin creation script
    spec = importlib.util.spec_from_file_location("create_admin", "create_admin.py")
    create_admin_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(create_admin_module)
    
    # Run the function
    print("Creating admin user...")
    create_admin_module.create_admin_user()

def add_sample_data():
    """Add sample data to the database"""
    import importlib.util
    
    # Import the sample data script
    spec = importlib.util.spec_from_file_location("add_sample_data", "add_sample_data.py")
    sample_data_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(sample_data_module)
    
    # Run the function
    print("Adding sample data...")
    sample_data_module.add_sample_data()

def reset_database():
    """Reset the database to a fresh state"""
    from app import db, app
    import os
    
    with app.app_context():
        # Drop all tables
        print("Dropping all tables...")
        db.drop_all()
        
        # Recreate tables
        print("Recreating tables...")
        db.create_all()
        
        print("Database has been reset.")

def run_server():
    """Run the development server"""
    from main import app
    
    print("Starting development server...")
    app.run(host="0.0.0.0", port=5000, debug=True)

def main():
    """Main function to parse arguments and run commands"""
    parser = argparse.ArgumentParser(description="AniStream setup and management tool")
    
    # Add subparsers for different commands
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Setup command
    setup_parser = subparsers.add_parser("setup", help="Setup the application")
    setup_parser.add_argument("--with-sample-data", action="store_true", 
                              help="Include sample data in setup")
    
    # Reset command
    reset_parser = subparsers.add_parser("reset", help="Reset the database")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Run the development server")
    
    # Add admin
    admin_parser = subparsers.add_parser("add-admin", help="Add admin user")
    
    # Add sample data
    sample_parser = subparsers.add_parser("add-sample-data", help="Add sample data")
    
    # Parse arguments
    args = parser.parse_args()
    
    # Setup environment variables
    setup_environment()
    
    # Execute command
    if args.command == "setup":
        init_database()
        add_admin()
        if args.with_sample_data:
            add_sample_data()
        print("Setup complete!")
        
    elif args.command == "reset":
        reset_database()
        print("Reset complete!")
        
    elif args.command == "run":
        run_server()
        
    elif args.command == "add-admin":
        add_admin()
        
    elif args.command == "add-sample-data":
        add_sample_data()
        
    else:
        parser.print_help()

if __name__ == "__main__":
    main()