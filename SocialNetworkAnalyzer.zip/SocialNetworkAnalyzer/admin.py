from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_required, current_user
from app import db
from models import Anime, Episode, Genre, User, Comment, anime_genre
from functools import wraps
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, IntegerField, BooleanField, SelectMultipleField, SubmitField, FieldList, FormField
from wtforms.validators import DataRequired, Length, NumberRange, URL, Optional
from wtforms.fields import DateField
from datetime import datetime

admin_bp = Blueprint('admin', __name__)

# Admin required decorator
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('You do not have permission to access this page.', 'danger')
            return redirect(url_for('anime.index'))
        return f(*args, **kwargs)
    return decorated_function

# Form classes
class AnimeForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired(), Length(max=120)])
    alt_title = StringField('Alternative Title', validators=[Optional(), Length(max=120)])
    synopsis = TextAreaField('Synopsis', validators=[DataRequired()])
    cover_image = StringField('Cover Image URL', validators=[DataRequired(), URL(), Length(max=255)])
    banner_image = StringField('Banner Image URL', validators=[Optional(), URL(), Length(max=255)])
    release_year = IntegerField('Release Year', validators=[Optional(), NumberRange(min=1950, max=2100)])
    status = SelectField('Status', choices=[('ongoing', 'Ongoing'), ('completed', 'Completed')])
    genres = SelectMultipleField('Genres', coerce=int)
    submit = SubmitField('Save')

class VideoQualityForm(FlaskForm):
    quality = SelectField('Quality', choices=[
        ('360', '360p'), 
        ('480', '480p'), 
        ('720', 'HD (720p)'), 
        ('1080', 'Full HD (1080p)')
    ])
    url = StringField('Video URL', validators=[
        DataRequired(message="Video URL is required"),
        URL(message="Please enter a valid URL"),
        Length(max=255, message="URL cannot exceed 255 characters")
    ])
    submit = SubmitField('Save Quality')

class EpisodeForm(FlaskForm):
    anime_id = SelectField('Anime', coerce=int, validators=[DataRequired()])
    title = StringField('Episode Title', validators=[Optional(), Length(max=120)])
    number = IntegerField('Episode Number', validators=[DataRequired(), NumberRange(min=1)])
    video_url = StringField('Main Video URL (720p)', validators=[DataRequired(), URL(), Length(max=255)])
    thumbnail = StringField('Thumbnail URL', validators=[Optional(), URL(), Length(max=255)])
    duration = IntegerField('Duration (seconds)', validators=[Optional(), NumberRange(min=1)])
    release_date = DateField('Release Date', validators=[Optional()])
    is_published = BooleanField('Published')
    
    # Additional video quality URLs
    video_360p = StringField('Video URL (360p)', validators=[Optional(), URL(), Length(max=255)])
    video_480p = StringField('Video URL (480p)', validators=[Optional(), URL(), Length(max=255)])
    video_1080p = StringField('Video URL (1080p)', validators=[Optional(), URL(), Length(max=255)])
    
    submit = SubmitField('Save')

# Routes
@admin_bp.route('/')
@login_required
@admin_required
def dashboard():
    # Get counts for the dashboard
    anime_count = Anime.query.count()
    episode_count = Episode.query.count()
    user_count = User.query.count()
    comment_count = Comment.query.count()
    
    # Get recent anime
    recent_anime = Anime.query.order_by(Anime.created_at.desc()).limit(5).all()
    
    # Get recent users
    recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    
    return render_template('admin/dashboard.html',
                          anime_count=anime_count,
                          episode_count=episode_count,
                          user_count=user_count,
                          comment_count=comment_count,
                          recent_anime=recent_anime,
                          recent_users=recent_users)

@admin_bp.route('/anime')
@login_required
@admin_required
def anime_list():
    anime = Anime.query.order_by(Anime.title).all()
    return render_template('admin/anime_list.html', anime_list=anime)

@admin_bp.route('/anime/new', methods=['GET', 'POST'])
@login_required
@admin_required
def add_anime():
    form = AnimeForm()
    
    # Populate genres field
    genres = Genre.query.order_by(Genre.name).all()
    form.genres.choices = [(g.id, g.name) for g in genres]
    
    if form.validate_on_submit():
        anime = Anime(
            title=form.title.data,
            alt_title=form.alt_title.data,
            synopsis=form.synopsis.data,
            cover_image=form.cover_image.data,
            banner_image=form.banner_image.data,
            release_year=form.release_year.data,
            status=form.status.data
        )
        
        # Add genres
        selected_genres = Genre.query.filter(Genre.id.in_(form.genres.data)).all()
        anime.genres = selected_genres
        
        db.session.add(anime)
        db.session.commit()
        
        flash(f"Anime '{anime.title}' has been added!", 'success')
        return redirect(url_for('admin.anime_list'))
    
    return render_template('admin/anime_form.html', form=form, title='Add New Anime')

@admin_bp.route('/anime/edit/<int:anime_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_anime(anime_id):
    anime = Anime.query.get_or_404(anime_id)
    form = AnimeForm(obj=anime)
    
    # Populate genres field
    genres = Genre.query.order_by(Genre.name).all()
    form.genres.choices = [(g.id, g.name) for g in genres]
    
    if request.method == 'GET':
        form.genres.data = [g.id for g in anime.genres]
    
    if form.validate_on_submit():
        anime.title = form.title.data
        anime.alt_title = form.alt_title.data
        anime.synopsis = form.synopsis.data
        anime.cover_image = form.cover_image.data
        anime.banner_image = form.banner_image.data
        anime.release_year = form.release_year.data
        anime.status = form.status.data
        
        # Update genres
        selected_genres = Genre.query.filter(Genre.id.in_(form.genres.data)).all()
        anime.genres = selected_genres
        
        db.session.commit()
        
        flash(f"Anime '{anime.title}' has been updated!", 'success')
        return redirect(url_for('admin.anime_list'))
    
    return render_template('admin/anime_form.html', form=form, anime=anime, title='Edit Anime')

@admin_bp.route('/anime/delete/<int:anime_id>', methods=['POST'])
@login_required
@admin_required
def delete_anime(anime_id):
    anime = Anime.query.get_or_404(anime_id)
    title = anime.title
    
    db.session.delete(anime)
    db.session.commit()
    
    flash(f"Anime '{title}' has been deleted!", 'success')
    return redirect(url_for('admin.anime_list'))

@admin_bp.route('/episodes')
@login_required
@admin_required
def episode_list():
    episodes = db.session.query(Episode, Anime).join(Anime).order_by(Anime.title, Episode.number).all()
    return render_template('admin/episode_list.html', episodes=episodes)

@admin_bp.route('/episode/new', methods=['GET', 'POST'])
@login_required
@admin_required
def add_episode():
    form = EpisodeForm()
    
    # Populate anime selection
    anime_list = Anime.query.order_by(Anime.title).all()
    form.anime_id.choices = [(a.id, a.title) for a in anime_list]
    
    if form.validate_on_submit():
        # Create base episode object with 720p video as default
        episode = Episode(
            anime_id=form.anime_id.data,
            title=form.title.data,
            number=form.number.data,
            video_url=form.video_url.data,  # Main URL (720p)
            thumbnail=form.thumbnail.data,
            duration=form.duration.data,
            release_date=form.release_date.data or datetime.now().date(),
            is_published=form.is_published.data
        )
        
        # Store different video quality URLs in episode extra_data
        episode_extra_data = {
            'video_qualities': {
                '360': form.video_360p.data or '',
                '480': form.video_480p.data or '',
                '720': form.video_url.data,  # Main URL
                '1080': form.video_1080p.data or ''
            }
        }
        
        # Convert to JSON string
        import json
        episode.extra_data = json.dumps(episode_extra_data)
        
        db.session.add(episode)
        db.session.commit()
        
        flash(f"Episode {episode.number} has been added with multiple video qualities!", 'success')
        return redirect(url_for('admin.episode_list'))
    
    return render_template('admin/episode_form.html', form=form, title='Add New Episode')

@admin_bp.route('/episode/edit/<int:episode_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_episode(episode_id):
    episode = Episode.query.get_or_404(episode_id)
    form = EpisodeForm(obj=episode)
    
    # Populate anime selection
    anime_list = Anime.query.order_by(Anime.title).all()
    form.anime_id.choices = [(a.id, a.title) for a in anime_list]
    
    # If it's a GET request, populate quality URLs from extra_data
    if request.method == 'GET':
        # Get video quality URLs from extra_data
        import json
        extra_data = {}
        if hasattr(episode, 'extra_data') and episode.extra_data:
            try:
                extra_data = json.loads(episode.extra_data)
                video_qualities = extra_data.get('video_qualities', {})
                # Set form fields
                form.video_360p.data = video_qualities.get('360', '')
                form.video_480p.data = video_qualities.get('480', '')
                form.video_1080p.data = video_qualities.get('1080', '')
            except json.JSONDecodeError:
                flash("Could not parse episode extra data", "warning")
    
    if form.validate_on_submit():
        episode.anime_id = form.anime_id.data
        episode.title = form.title.data
        episode.number = form.number.data
        episode.video_url = form.video_url.data  # Main URL (720p)
        episode.thumbnail = form.thumbnail.data
        episode.duration = form.duration.data
        episode.release_date = form.release_date.data or datetime.now().date()
        episode.is_published = form.is_published.data
        
        # Update episode extra_data with video quality URLs
        import json
        episode_extra_data = {}
        
        # Parse existing extra_data if available
        if hasattr(episode, 'extra_data') and episode.extra_data:
            try:
                episode_extra_data = json.loads(episode.extra_data)
            except json.JSONDecodeError:
                episode_extra_data = {}
        
        # Update or create video qualities
        episode_extra_data['video_qualities'] = {
            '360': form.video_360p.data or '',
            '480': form.video_480p.data or '',
            '720': form.video_url.data,  # Main URL
            '1080': form.video_1080p.data or ''
        }
        
        # Save extra_data
        episode.extra_data = json.dumps(episode_extra_data)
        
        db.session.commit()
        
        flash(f"Episode {episode.number} has been updated with multiple video qualities!", 'success')
        return redirect(url_for('admin.episode_list'))
    
    return render_template('admin/episode_form.html', form=form, episode=episode, title='Edit Episode')

@admin_bp.route('/episode/delete/<int:episode_id>', methods=['POST'])
@login_required
@admin_required
def delete_episode(episode_id):
    episode = Episode.query.get_or_404(episode_id)
    anime_title = episode.anime.title
    episode_number = episode.number
    
    db.session.delete(episode)
    db.session.commit()
    
    flash(f"Episode {episode_number} of '{anime_title}' has been deleted!", 'success')
    return redirect(url_for('admin.episode_list'))

@admin_bp.route('/users')
@login_required
@admin_required
def user_list():
    users = User.query.order_by(User.username).all()
    return render_template('admin/users.html', users=users)

@admin_bp.route('/user/toggle-admin/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def toggle_admin(user_id):
    user = User.query.get_or_404(user_id)
    
    # Prevent removing admin from oneself
    if user.id == current_user.id:
        flash('You cannot remove admin privileges from yourself.', 'danger')
        return redirect(url_for('admin.user_list'))
    
    user.is_admin = not user.is_admin
    db.session.commit()
    
    status = 'granted' if user.is_admin else 'revoked'
    flash(f"Admin privileges for '{user.username}' have been {status}.", 'success')
    return redirect(url_for('admin.user_list'))

@admin_bp.route('/genres')
@login_required
@admin_required
def genre_list():
    genres = Genre.query.order_by(Genre.name).all()
    return render_template('admin/genres.html', genres=genres)

@admin_bp.route('/genre/new', methods=['POST'])
@login_required
@admin_required
def add_genre():
    name = request.form.get('name')
    
    if not name:
        flash('Genre name is required.', 'danger')
        return redirect(url_for('admin.genre_list'))
    
    existing_genre = Genre.query.filter_by(name=name).first()
    if existing_genre:
        flash(f"Genre '{name}' already exists.", 'danger')
        return redirect(url_for('admin.genre_list'))
    
    genre = Genre(name=name)
    db.session.add(genre)
    db.session.commit()
    
    flash(f"Genre '{name}' has been added!", 'success')
    return redirect(url_for('admin.genre_list'))

@admin_bp.route('/genre/delete/<int:genre_id>', methods=['POST'])
@login_required
@admin_required
def delete_genre(genre_id):
    genre = Genre.query.get_or_404(genre_id)
    name = genre.name
    
    db.session.delete(genre)
    db.session.commit()
    
    flash(f"Genre '{name}' has been deleted!", 'success')
    return redirect(url_for('admin.genre_list'))

@admin_bp.route('/episode/qualities/<int:episode_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def manage_episode_qualities(episode_id):
    episode = Episode.query.get_or_404(episode_id)
    
    # Get current quality URLs
    import json
    quality_urls = {}
    if hasattr(episode, 'extra_data') and episode.extra_data:
        try:
            extra_data = json.loads(episode.extra_data)
            quality_urls = extra_data.get('video_qualities', {})
        except json.JSONDecodeError:
            flash("Could not parse episode extra data", "warning")
    
    # Add default quality (main URL)
    if '720' not in quality_urls:
        quality_urls['720'] = episode.video_url
    
    # Create forms for each quality
    quality_forms = {}
    for quality in ['360', '480', '720', '1080']:
        form = VideoQualityForm(prefix=f"quality_{quality}")
        form.quality.data = quality
        form.url.data = quality_urls.get(quality, '')
        quality_forms[quality] = form
    
    # Handle form submission
    if request.method == 'POST':
        # Determine which form was submitted
        for quality, form in quality_forms.items():
            if form.submit.data and form.validate():
                # Update quality URL
                quality_urls[quality] = form.url.data
                
                # Save to extra_data
                extra_data = {}
                if hasattr(episode, 'extra_data') and episode.extra_data:
                    try:
                        extra_data = json.loads(episode.extra_data)
                    except json.JSONDecodeError:
                        extra_data = {}
                
                extra_data['video_qualities'] = quality_urls
                episode.extra_data = json.dumps(extra_data)
                
                # If 720p quality was updated, also update main URL
                if quality == '720':
                    episode.video_url = form.url.data
                
                db.session.commit()
                flash(f"{quality}p video quality updated for episode {episode.number}!", "success")
                return redirect(url_for('admin.manage_episode_qualities', episode_id=episode_id))
    
    return render_template('admin/episode_qualities.html', 
                          episode=episode, 
                          quality_forms=quality_forms,
                          title=f"Manage Video Qualities - Episode {episode.number}")
