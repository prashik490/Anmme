/**
 * Main JavaScript functionality for Anime Streaming Website
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    initializeTooltips();
    
    // Initialize star rating on any rating elements
    initializeStarRating();
    
    // Initialize watchlist toggle buttons
    initializeWatchlistToggles();
    
    // Initialize search functionality
    initializeSearch();
    
    // Anime card hover effects
    initializeCardHoverEffects();
    
    // Initialize carousel auto-play if present
    initializeCarousel();
});

/**
 * Initialize Bootstrap tooltips
 */
function initializeTooltips() {
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
}

/**
 * Initialize star rating system
 */
function initializeStarRating() {
    const ratingContainers = document.querySelectorAll('.star-rating');
    
    ratingContainers.forEach(container => {
        const stars = container.querySelectorAll('.star');
        const valueInput = container.querySelector('input[type="hidden"]');
        
        // Display current rating
        if (valueInput) {
            const currentValue = parseInt(valueInput.value);
            updateStars(stars, currentValue);
        }
        
        // Add click event to stars
        stars.forEach((star, index) => {
            star.addEventListener('click', () => {
                const value = index + 1;
                
                // Update visual stars
                updateStars(stars, value);
                
                // Update hidden input value
                if (valueInput) {
                    valueInput.value = value;
                }
                
                // If this is in a form, submit it
                const form = container.closest('form');
                if (form && form.dataset.autoSubmit === 'true') {
                    form.submit();
                }
            });
            
            // Hover effects
            star.addEventListener('mouseenter', () => {
                updateStars(stars, index + 1, true);
            });
            
            star.addEventListener('mouseleave', () => {
                if (valueInput) {
                    const currentValue = parseInt(valueInput.value || 0);
                    updateStars(stars, currentValue);
                } else {
                    updateStars(stars, 0);
                }
            });
        });
    });
}

/**
 * Update star visuals based on rating value
 */
function updateStars(stars, value, isHover = false) {
    stars.forEach((star, index) => {
        if (index < value) {
            star.classList.add('filled');
            star.innerHTML = '<i class="fas fa-star"></i>';
        } else {
            star.classList.remove('filled');
            star.innerHTML = '<i class="far fa-star"></i>';
        }
    });
}

/**
 * Initialize watchlist toggle buttons with AJAX functionality
 */
function initializeWatchlistToggles() {
    const watchlistButtons = document.querySelectorAll('.watchlist-toggle');
    
    watchlistButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const animeId = this.dataset.animeId;
            const url = `/watchlist/toggle/${animeId}`;
            
            // Send AJAX request
            fetch(url, {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Content-Type': 'application/json'
                },
                credentials: 'same-origin'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Toggle active class on button
                    this.classList.toggle('active');
                    
                    // Update icon
                    const icon = this.querySelector('i');
                    if (data.in_watchlist) {
                        icon.classList.remove('far');
                        icon.classList.add('fas');
                        this.setAttribute('data-bs-original-title', 'Remove from watchlist');
                    } else {
                        icon.classList.remove('fas');
                        icon.classList.add('far');
                        this.setAttribute('data-bs-original-title', 'Add to watchlist');
                    }
                    
                    // Update tooltip
                    const tooltip = bootstrap.Tooltip.getInstance(this);
                    if (tooltip) {
                        tooltip.dispose();
                        new bootstrap.Tooltip(this);
                    }
                    
                    // Show notification
                    showNotification(data.message, 'success');
                }
            })
            .catch(error => {
                console.error('Error toggling watchlist:', error);
                showNotification('Failed to update watchlist. Please try again.', 'danger');
            });
        });
    });
}

/**
 * Show a notification message
 */
function showNotification(message, type = 'info') {
    // Check if notification container exists, create if not
    let container = document.querySelector('.notification-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'notification-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(container);
    }
    
    // Create toast element
    const toastId = 'toast-' + Date.now();
    const toastHtml = `
        <div id="${toastId}" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-${type} text-white">
                <strong class="me-auto">Notification</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body bg-dark text-white">
                ${message}
            </div>
        </div>
    `;
    
    // Add toast to container
    container.insertAdjacentHTML('beforeend', toastHtml);
    
    // Initialize and show toast
    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, { autohide: true, delay: 5000 });
    toast.show();
    
    // Remove toast after it's hidden
    toastElement.addEventListener('hidden.bs.toast', function() {
        toastElement.remove();
    });
}

/**
 * Initialize search autocomplete functionality
 */
function initializeSearch() {
    const searchInput = document.querySelector('.search-input');
    
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const query = this.value.trim();
            
            if (query.length < 2) {
                return;
            }
            
            // Debounce the search
            clearTimeout(this.searchTimeout);
            this.searchTimeout = setTimeout(() => {
                fetch(`/search?q=${encodeURIComponent(query)}&format=json`)
                    .then(response => response.json())
                    .then(data => {
                        // Handle autocomplete suggestions here
                        updateAutocompleteResults(data.results);
                    })
                    .catch(error => {
                        console.error('Error fetching search results:', error);
                    });
            }, 300);
        });
    }
}

/**
 * Update autocomplete results dropdown
 */
function updateAutocompleteResults(results) {
    // This would be implemented based on your search results structure
    // and the HTML structure of your autocomplete dropdown
}

/**
 * Initialize anime card hover effects
 */
function initializeCardHoverEffects() {
    const animeCards = document.querySelectorAll('.anime-card');
    
    animeCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.classList.add('shadow-lg');
        });
        
        card.addEventListener('mouseleave', function() {
            this.classList.remove('shadow-lg');
        });
    });
}

/**
 * Initialize Bootstrap carousel
 */
function initializeCarousel() {
    const carousel = document.querySelector('#featured-carousel');
    if (carousel) {
        const carouselInstance = new bootstrap.Carousel(carousel, {
            interval: 5000,
            wrap: true
        });
    }
}

/**
 * Lazy-load images when they come into view
 */
document.addEventListener('DOMContentLoaded', function() {
    const lazyImages = document.querySelectorAll('img[data-src]');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                    imageObserver.unobserve(img);
                }
            });
        });
        
        lazyImages.forEach(img => {
            imageObserver.observe(img);
        });
    } else {
        // Fallback for browsers without intersection observer
        lazyImages.forEach(img => {
            img.src = img.dataset.src;
            img.removeAttribute('data-src');
        });
    }
});
