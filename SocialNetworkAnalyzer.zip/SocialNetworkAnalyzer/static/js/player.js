/**
 * Video player functionality for anime streaming
 */

let player = null;
let currentPosition = 0;
let watchHistoryTimer = null;
let episodeId = null;
let currentQuality = '720p';

document.addEventListener('DOMContentLoaded', function() {
    initializePlayer();
    setupCustomQualityControls();
});

/**
 * Initialize the Plyr video player
 */
function initializePlayer() {
    const videoElement = document.querySelector('video');
    
    if (!videoElement) {
        return;
    }
    
    episodeId = videoElement.dataset.episodeId;
    const startPosition = parseInt(videoElement.dataset.startPosition || 0);
    
    // Initialize Plyr
    player = new Plyr(videoElement, {
        controls: [
            'play-large', 'play', 'progress', 'current-time', 'mute', 
            'volume', 'captions', 'settings', 'pip', 'airplay', 'fullscreen'
        ],
        quality: {
            default: 720,
            options: [360, 480, 720, 1080]
        },
        i18n: {
            qualityLabel: {
                360: '360p',
                480: '480p',
                720: 'HD (720p)',
                1080: 'Full HD (1080p)'
            }
        },
        seekTime: 10,
        keyboard: { focused: true, global: true },
        storage: { enabled: true, key: 'anistream-player-preferences' }
    });

    // Set up event listeners
    player.on('ready', () => {
        console.log('Player is ready');
        
        // If there's a saved position, seek to it
        if (startPosition > 0) {
            player.currentTime = startPosition;
        }
        
        // Start tracking watch history
        startWatchHistoryTracking();
        
        // Add custom quality control panel
        createCustomQualityPanel();
    });
    
    player.on('playing', () => {
        console.log('Player is playing');
    });
    
    player.on('pause', () => {
        console.log('Player is paused');
        // Save position when paused
        saveWatchPosition();
    });
    
    player.on('ended', () => {
        console.log('Playback ended');
        // Mark as completed when ended
        saveWatchPosition(true);
        
        // Show next episode overlay if available
        showNextEpisodeOverlay();
    });
    
    player.on('qualitychange', event => {
        // Update our custom quality buttons
        currentQuality = player.quality;
        updateQualityButtons(currentQuality);
    });
    
    // Add custom keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Next episode: Shift + N
        if (e.shiftKey && e.key.toLowerCase() === 'n') {
            const nextEpisodeBtn = document.querySelector('.next-episode-btn');
            if (nextEpisodeBtn) {
                nextEpisodeBtn.click();
            }
        }
        
        // Previous episode: Shift + P
        if (e.shiftKey && e.key.toLowerCase() === 'p') {
            const prevEpisodeBtn = document.querySelector('.prev-episode-btn');
            if (prevEpisodeBtn) {
                prevEpisodeBtn.click();
            }
        }
        
        // Quality shortcuts
        if (e.altKey) {
            switch(e.key) {
                case '1': setVideoQuality(360); break;
                case '2': setVideoQuality(480); break;
                case '3': setVideoQuality(720); break;
                case '4': setVideoQuality(1080); break;
            }
        }
    });
}

/**
 * Create custom quality selection panel
 */
function createCustomQualityPanel() {
    const playerContainer = document.querySelector('.plyr__controls');
    
    if (!playerContainer) return;
    
    // Create custom quality control container
    const qualityContainer = document.createElement('div');
    qualityContainer.className = 'custom-quality-control';
    qualityContainer.style.position = 'absolute';
    qualityContainer.style.top = '15px';
    qualityContainer.style.right = '15px';
    qualityContainer.style.zIndex = '10';
    qualityContainer.style.display = 'flex';
    qualityContainer.style.gap = '5px';
    
    // Create quality buttons
    const qualities = [
        { value: 360, label: '360p' },
        { value: 480, label: '480p' },
        { value: 720, label: 'HD' },
        { value: 1080, label: 'FHD' }
    ];
    
    qualities.forEach(quality => {
        const button = document.createElement('button');
        button.className = `quality-btn quality-${quality.value} btn-neon btn-sm`;
        button.textContent = quality.label;
        button.dataset.quality = quality.value;
        button.style.padding = '3px 8px';
        button.style.fontSize = '0.75rem';
        button.style.opacity = '0.7';
        button.style.transition = 'all 0.3s ease';
        
        button.addEventListener('click', () => {
            setVideoQuality(quality.value);
        });
        
        qualityContainer.appendChild(button);
    });
    
    // Append to video container
    const videoContainer = document.querySelector('.video-container');
    if (videoContainer) {
        videoContainer.style.position = 'relative';
        videoContainer.appendChild(qualityContainer);
        
        // Update active button
        updateQualityButtons(player.quality || 720);
    }
}

/**
 * Start tracking watch history at regular intervals
 */
function startWatchHistoryTracking() {
    // Clear any existing timer
    if (watchHistoryTimer) {
        clearInterval(watchHistoryTimer);
    }
    
    // Save position every 30 seconds
    watchHistoryTimer = setInterval(() => {
        saveWatchPosition();
    }, 30000); // 30 seconds
}

/**
 * Save the current watch position to the server
 */
function saveWatchPosition(completed = false) {
    if (!player || !episodeId) {
        return;
    }
    
    // Get current position in seconds
    currentPosition = Math.floor(player.currentTime);
    
    // Don't save if position is very small and not completed
    if (currentPosition < 10 && !completed) {
        return;
    }
    
    // Save to the server via fetch API
    fetch(`/watchhistory/update/${episodeId}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
            position: currentPosition,
            completed: completed
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log('Watch position saved:', currentPosition, 'Completed:', completed);
        } else {
            console.error('Failed to save watch position');
        }
    })
    .catch(error => {
        console.error('Error saving watch position:', error);
    });
}

/**
 * Handle switching to a different episode
 */
function switchEpisode(episodeUrl) {
    // Save current position before switching
    saveWatchPosition();
    
    // Navigate to the new episode
    window.location.href = episodeUrl;
}

/**
 * Function to toggle video quality
 */
function setVideoQuality(quality) {
    if (!player) {
        return;
    }
    
    // First try to use our custom quality URLs
    const videoElement = document.querySelector('video');
    if (videoElement && videoElement.dataset.qualityUrls) {
        try {
            const qualityUrls = JSON.parse(videoElement.dataset.qualityUrls);
            const qualityKey = quality.toString();
            
            // If we have a URL for this quality
            if (qualityUrls[qualityKey] && qualityUrls[qualityKey].length > 0) {
                // Save current time before changing source
                const currentTime = player.currentTime;
                const wasPlaying = !player.paused;
                
                // Change the source
                videoElement.src = qualityUrls[qualityKey];
                player.source = {
                    type: 'video',
                    sources: [
                        {
                            src: qualityUrls[qualityKey],
                            type: 'video/mp4',
                            size: quality
                        }
                    ]
                };
                
                // Update current quality display
                currentQuality = quality;
                updateQualityButtons(quality);
                
                // Resume playback at the same position
                player.on('ready', () => {
                    player.currentTime = currentTime;
                    if (wasPlaying) {
                        player.play();
                    }
                });
                
                return;
            }
        } catch (e) {
            console.error('Error parsing quality URLs:', e);
        }
    }
    
    // Fallback to built-in Plyr quality switching
    player.quality = quality;
    
    // Update buttons in the quality selection bar
    updateQualitySelectionBar(quality);
}

/**
 * Handle fullscreen toggle with custom button
 */
function toggleFullscreen() {
    if (!player) {
        return;
    }
    
    player.fullscreen.toggle();
}

/**
 * Update the quality buttons to show the active quality
 */
function updateQualityButtons(activeQuality) {
    const qualityButtons = document.querySelectorAll('.quality-btn');
    
    qualityButtons.forEach(button => {
        const buttonQuality = parseInt(button.dataset.quality);
        
        // Reset styles
        button.style.opacity = '0.7';
        button.style.fontWeight = 'normal';
        button.style.transform = 'none';
        
        if (buttonQuality === activeQuality) {
            button.style.opacity = '1';
            button.style.fontWeight = 'bold';
            button.style.transform = 'scale(1.1)';
        }
    });
}

/**
 * Update the selection bar with the active quality button
 */
function updateQualitySelectionBar(activeQuality) {
    // Select all quality buttons from the quality selection bar
    const qualityButtons = document.querySelectorAll('.btn-quality');
    
    // Remove active class from all buttons
    qualityButtons.forEach(button => {
        button.classList.remove('btn-quality-active');
    });
    
    // Add active class to the current quality button
    const activeButton = document.querySelector(`.btn-quality[data-quality="${activeQuality}"]`);
    if (activeButton) {
        activeButton.classList.add('btn-quality-active');
    }
}

/**
 * Set up custom quality selection controls
 */
function setupCustomQualityControls() {
    // Add quality selector dropdown if not using the Plyr builtin
    const qualitySelect = document.getElementById('quality-select');
    if (qualitySelect) {
        qualitySelect.addEventListener('change', function() {
            setVideoQuality(parseInt(this.value));
        });
    }
}

/**
 * Show next episode overlay when current episode ends
 */
function showNextEpisodeOverlay() {
    const nextEpisodeBtn = document.querySelector('.next-episode-btn');
    if (!nextEpisodeBtn) return;
    
    const overlay = document.createElement('div');
    overlay.className = 'next-episode-overlay';
    overlay.style.position = 'absolute';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    overlay.style.display = 'flex';
    overlay.style.flexDirection = 'column';
    overlay.style.justifyContent = 'center';
    overlay.style.alignItems = 'center';
    overlay.style.zIndex = '20';
    
    const message = document.createElement('h3');
    message.textContent = 'Episode Completed';
    message.style.color = 'white';
    message.style.marginBottom = '1rem';
    
    const countdown = document.createElement('div');
    countdown.textContent = 'Next episode starting in 10s';
    countdown.style.color = 'white';
    countdown.style.marginBottom = '2rem';
    
    const buttonContainer = document.createElement('div');
    buttonContainer.style.display = 'flex';
    buttonContainer.style.gap = '1rem';
    
    const nextButton = document.createElement('button');
    nextButton.className = 'btn btn-neon btn-neon-green';
    nextButton.textContent = 'Next Episode';
    nextButton.addEventListener('click', function() {
        nextEpisodeBtn.click();
    });
    
    const cancelButton = document.createElement('button');
    cancelButton.className = 'btn btn-neon btn-neon-red';
    cancelButton.textContent = 'Cancel';
    cancelButton.addEventListener('click', function() {
        const videoContainer = document.querySelector('.video-container');
        if (videoContainer && videoContainer.contains(overlay)) {
            videoContainer.removeChild(overlay);
        }
    });
    
    buttonContainer.appendChild(nextButton);
    buttonContainer.appendChild(cancelButton);
    
    overlay.appendChild(message);
    overlay.appendChild(countdown);
    overlay.appendChild(buttonContainer);
    
    const videoContainer = document.querySelector('.video-container');
    if (videoContainer) {
        videoContainer.appendChild(overlay);
        
        // Countdown timer
        let secondsLeft = 10;
        const countdownInterval = setInterval(() => {
            secondsLeft--;
            countdown.textContent = `Next episode starting in ${secondsLeft}s`;
            
            if (secondsLeft <= 0) {
                clearInterval(countdownInterval);
                nextEpisodeBtn.click();
            }
        }, 1000);
    }
}

window.addEventListener('beforeunload', function() {
    // Save position before leaving the page
    saveWatchPosition();
    
    // Clear interval
    if (watchHistoryTimer) {
        clearInterval(watchHistoryTimer);
    }
});
