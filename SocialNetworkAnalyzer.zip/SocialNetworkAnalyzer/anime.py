from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify
from flask_login import login_required, current_user
from app import db
from models import Anime, Episode, Genre, WatchHistory, Comment, Rating, watchlist, anime_genre
from sqlalchemy import func, desc, or_
from datetime import datetime
from flask_wtf import FlaskForm
from wtforms import TextAreaField, SubmitField, IntegerField
from wtforms.validators import DataRequired, NumberRange

anime_bp = Blueprint('anime', __name__)

# Form classes
class CommentForm(FlaskForm):
    content = TextAreaField('Comment', validators=[DataRequired()])
    submit = SubmitField('Post Comment')

class RatingForm(FlaskForm):
    value = IntegerField('Rating (1-5)', validators=[DataRequired(), NumberRange(min=1, max=5)])
    submit = SubmitField('Rate')

# Routes
@anime_bp.route('/')
def index():
    # Get trending anime (by rating)
    trending_anime = Anime.query.order_by(desc(Anime.rating_avg), desc(Anime.rating_count)).limit(8).all()
    
    # Get recently added episodes
    recent_episodes = db.session.query(
        Episode, Anime
    ).join(
        Anime, Episode.anime_id == Anime.id
    ).filter(
        Episode.is_published == True
    ).order_by(
        Episode.created_at.desc()
    ).limit(12).all()
    
    # Get popular genres
    popular_genres = Genre.query.join(
        anime_genre
    ).group_by(
        Genre.id
    ).order_by(
        func.count(anime_genre.c.anime_id).desc()
    ).limit(6).all()
    
    # Get top rated anime
    top_rated_anime = Anime.query.order_by(desc(Anime.rating_avg)).limit(8).all()
    
    return render_template('index.html', 
                          trending_anime=trending_anime,
                          recent_episodes=recent_episodes,
                          popular_genres=popular_genres,
                          top_rated_anime=top_rated_anime)

@anime_bp.route('/anime/<int:anime_id>')
def anime_details(anime_id):
    anime = Anime.query.get_or_404(anime_id)
    episodes = anime.episodes.filter_by(is_published=True).order_by(Episode.number).all()
    
    # Get related anime (same genres)
    related_anime_ids = db.session.query(anime_genre.c.anime_id).join(
        Genre, anime_genre.c.genre_id == Genre.id
    ).filter(
        Genre.id.in_([g.id for g in anime.genres]),
        anime_genre.c.anime_id != anime.id
    ).group_by(
        anime_genre.c.anime_id
    ).order_by(
        func.count(anime_genre.c.genre_id).desc()
    ).limit(6).all()
    
    related_anime = Anime.query.filter(Anime.id.in_([id[0] for id in related_anime_ids])).all()
    
    # Get comments
    comments = Comment.query.filter_by(anime_id=anime.id).order_by(Comment.created_at.desc()).all()
    
    # Check if user has rated this anime
    user_rating = None
    if current_user.is_authenticated:
        user_rating = Rating.query.filter_by(user_id=current_user.id, anime_id=anime.id).first()
    
    # Create forms
    comment_form = CommentForm()
    rating_form = RatingForm()
    if user_rating:
        rating_form.value.data = user_rating.value
    
    # Check if anime is in user's watchlist
    is_in_watchlist = False
    if current_user.is_authenticated:
        is_in_watchlist = current_user.watchlist_items.filter_by(id=anime.id).first() is not None
    
    return render_template('anime_details.html', 
                          anime=anime,
                          episodes=episodes,
                          related_anime=related_anime,
                          comments=comments,
                          comment_form=comment_form,
                          rating_form=rating_form,
                          user_rating=user_rating,
                          is_in_watchlist=is_in_watchlist)

@anime_bp.route('/watch/<int:episode_id>')
def watch_episode(episode_id):
    episode = Episode.query.get_or_404(episode_id)
    anime = episode.anime
    
    # Get all episodes of this anime for the episode list
    episodes = anime.episodes.filter_by(is_published=True).order_by(Episode.number).all()
    
    # Get video quality URLs using the model method
    quality_urls = episode.get_quality_urls()
    
    # Get previous watch position if available
    start_position = 0
    if current_user.is_authenticated:
        # Check if there's an existing record
        watch_record = WatchHistory.query.filter_by(
            user_id=current_user.id,
            episode_id=episode.id
        ).first()
        
        if watch_record:
            # Update timestamp and get position
            watch_record.watched_at = datetime.utcnow()
            start_position = watch_record.position if not watch_record.completed else 0
        else:
            # Create new record
            watch_record = WatchHistory(
                user_id=current_user.id,
                anime_id=anime.id,
                episode_id=episode.id
            )
            db.session.add(watch_record)
        
        db.session.commit()
    
    return render_template('watch.html', 
                          episode=episode,
                          anime=anime,
                          episodes=episodes,
                          quality_urls=quality_urls,
                          start_position=start_position)

@anime_bp.route('/search')
def search():
    query = request.args.get('q', '')
    genre = request.args.get('genre', '')
    year = request.args.get('year', '')
    status = request.args.get('status', '')
    
    anime_query = Anime.query
    
    if query:
        anime_query = anime_query.filter(or_(
            Anime.title.ilike(f'%{query}%'),
            Anime.alt_title.ilike(f'%{query}%')
        ))
    
    if genre:
        anime_query = anime_query.join(
            anime_genre
        ).join(
            Genre
        ).filter(
            Genre.name == genre
        )
    
    if year:
        anime_query = anime_query.filter(Anime.release_year == int(year))
    
    if status:
        anime_query = anime_query.filter(Anime.status == status)
    
    results = anime_query.order_by(Anime.title).all()
    
    # Get all genres for filter dropdown
    genres = Genre.query.order_by(Genre.name).all()
    
    # Get all years for filter dropdown
    years = db.session.query(Anime.release_year).distinct().order_by(Anime.release_year.desc()).all()
    years = [year[0] for year in years if year[0] is not None]
    
    return render_template('search.html',
                          query=query,
                          results=results,
                          genres=genres,
                          years=years,
                          selected_genre=genre,
                          selected_year=year,
                          selected_status=status)

@anime_bp.route('/category/<string:genre_name>')
def category(genre_name):
    genre = Genre.query.filter_by(name=genre_name).first_or_404()
    
    anime_list = Anime.query.join(
        anime_genre
    ).filter(
        anime_genre.c.genre_id == genre.id
    ).all()
    
    return render_template('category.html',
                          genre=genre,
                          anime_list=anime_list)

@anime_bp.route('/comment/add/<int:anime_id>', methods=['POST'])
@login_required
def add_comment(anime_id):
    anime = Anime.query.get_or_404(anime_id)
    form = CommentForm()
    
    if form.validate_on_submit():
        comment = Comment(
            user_id=current_user.id,
            anime_id=anime.id,
            content=form.content.data
        )
        db.session.add(comment)
        db.session.commit()
        flash('Your comment has been posted!', 'success')
    
    return redirect(url_for('anime.anime_details', anime_id=anime.id))

@anime_bp.route('/rating/add/<int:anime_id>', methods=['POST'])
@login_required
def add_rating(anime_id):
    anime = Anime.query.get_or_404(anime_id)
    form = RatingForm()
    
    if form.validate_on_submit():
        # Check if user already rated this anime
        existing_rating = Rating.query.filter_by(
            user_id=current_user.id,
            anime_id=anime.id
        ).first()
        
        if existing_rating:
            # Update the existing rating
            old_rating = existing_rating.value
            existing_rating.value = form.value.data
            existing_rating.created_at = datetime.utcnow()
            
            # Update anime rating aggregate
            if anime.rating_count == 1:
                anime.rating_avg = form.value.data
            else:
                anime.rating_avg = (anime.rating_avg * anime.rating_count - old_rating + form.value.data) / anime.rating_count
            
            flash('Your rating has been updated!', 'success')
        else:
            # Create new rating
            rating = Rating(
                user_id=current_user.id,
                anime_id=anime.id,
                value=form.value.data
            )
            db.session.add(rating)
            
            # Update anime rating aggregate
            if anime.rating_count == 0:
                anime.rating_avg = form.value.data
            else:
                anime.rating_avg = (anime.rating_avg * anime.rating_count + form.value.data) / (anime.rating_count + 1)
            anime.rating_count += 1
            
            flash('Your rating has been saved!', 'success')
        
        db.session.commit()
    
    return redirect(url_for('anime.anime_details', anime_id=anime.id))

@anime_bp.route('/watchlist/toggle/<int:anime_id>', methods=['POST'])
@login_required
def toggle_watchlist(anime_id):
    anime = Anime.query.get_or_404(anime_id)
    
    # Check if anime is already in watchlist
    is_in_watchlist = current_user.watchlist_items.filter_by(id=anime.id).first() is not None
    
    if is_in_watchlist:
        # Remove from watchlist
        current_user.watchlist_items.remove(anime)
        message = f"'{anime.title}' has been removed from your watchlist."
    else:
        # Add to watchlist
        current_user.watchlist_items.append(anime)
        message = f"'{anime.title}' has been added to your watchlist."
    
    db.session.commit()
    flash(message, 'success')
    
    # If this is an AJAX request, return JSON response
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'message': message, 'in_watchlist': not is_in_watchlist})
    
    # Otherwise, redirect back to anime page
    return redirect(url_for('anime.anime_details', anime_id=anime.id))

@anime_bp.route('/watchhistory/update/<int:episode_id>', methods=['POST'])
@login_required
def update_watch_history(episode_id):
    episode = Episode.query.get_or_404(episode_id)
    
    # Get position from request
    position = request.json.get('position', 0)
    completed = request.json.get('completed', False)
    
    # Find or create watch history entry
    watch_record = WatchHistory.query.filter_by(
        user_id=current_user.id,
        episode_id=episode.id
    ).first()
    
    if not watch_record:
        watch_record = WatchHistory(
            user_id=current_user.id,
            anime_id=episode.anime.id,
            episode_id=episode.id
        )
        db.session.add(watch_record)
    
    # Update position and status
    watch_record.position = position
    watch_record.completed = completed
    watch_record.watched_at = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({'success': True})

@anime_bp.route('/documentation')
@login_required
def documentation():
    """Render the comprehensive documentation page - admin only"""
    if not current_user.is_admin:
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('anime.index'))
    return render_template('documentation.html')
