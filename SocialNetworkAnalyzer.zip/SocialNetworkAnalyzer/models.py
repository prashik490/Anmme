from datetime import datetime
from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

# Association tables for many-to-many relationships
anime_genre = db.Table('anime_genre',
    db.Column('anime_id', db.Integer, db.ForeignKey('anime.id'), primary_key=True),
    db.Column('genre_id', db.Integer, db.ForeignKey('genre.id'), primary_key=True)
)

watchlist = db.Table('watchlist',
    db.Column('user_id', db.Integer, db.ForeignKey('user.id'), primary_key=True),
    db.Column('anime_id', db.Integer, db.ForeignKey('anime.id'), primary_key=True),
    db.Column('added_on', db.DateTime, default=datetime.utcnow)
)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    watch_history = db.relationship('WatchHistory', back_populates='user', lazy='dynamic')
    comments = db.relationship('Comment', back_populates='user', lazy='dynamic')
    ratings = db.relationship('Rating', back_populates='user', lazy='dynamic')
    watchlist_items = db.relationship('Anime', secondary=watchlist, lazy='dynamic',
                                     backref=db.backref('watchlisted_by', lazy='dynamic'))
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Genre(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    
    def __repr__(self):
        return f'<Genre {self.name}>'

class Anime(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False)
    alt_title = db.Column(db.String(120))
    synopsis = db.Column(db.Text)
    cover_image = db.Column(db.String(255))
    banner_image = db.Column(db.String(255))
    release_year = db.Column(db.Integer)
    status = db.Column(db.String(20))  # ongoing, completed
    rating_avg = db.Column(db.Float, default=0.0)
    rating_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    genres = db.relationship('Genre', secondary=anime_genre, lazy='joined',
                            backref=db.backref('anime', lazy='dynamic'))
    episodes = db.relationship('Episode', back_populates='anime', lazy='dynamic',
                              cascade='all, delete-orphan')
    comments = db.relationship('Comment', back_populates='anime', lazy='dynamic',
                              cascade='all, delete-orphan')
    ratings = db.relationship('Rating', back_populates='anime', lazy='dynamic',
                             cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Anime {self.title}>'

class Episode(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    anime_id = db.Column(db.Integer, db.ForeignKey('anime.id'), nullable=False)
    title = db.Column(db.String(120))
    number = db.Column(db.Integer, nullable=False)
    video_url = db.Column(db.String(255), nullable=False)
    thumbnail = db.Column(db.String(255))
    duration = db.Column(db.Integer)  # in seconds
    release_date = db.Column(db.DateTime)
    is_published = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    extra_data = db.Column(db.Text)  # Store additional data as JSON (video qualities, etc)
    
    # Relationships
    anime = db.relationship('Anime', back_populates='episodes')
    watch_history = db.relationship('WatchHistory', back_populates='episode', lazy='dynamic')
    
    def get_quality_urls(self):
        """Get all available video quality URLs for this episode"""
        quality_urls = {'720': self.video_url}  # Default quality is 720p
        
        if self.extra_data:
            try:
                import json
                extra_data = json.loads(self.extra_data)
                if 'video_qualities' in extra_data and isinstance(extra_data['video_qualities'], dict):
                    # Update with qualities from extra_data
                    quality_urls.update(extra_data['video_qualities'])
            except (json.JSONDecodeError, TypeError, ValueError):
                pass
        
        return quality_urls
    
    def update_quality_url(self, quality, url):
        """Update a specific quality URL in the extra_data field"""
        import json
        
        extra_data = {}
        if self.extra_data:
            try:
                extra_data = json.loads(self.extra_data)
            except (json.JSONDecodeError, TypeError):
                extra_data = {}
        
        if 'video_qualities' not in extra_data:
            extra_data['video_qualities'] = {}
        
        # Update the specific quality URL
        extra_data['video_qualities'][quality] = url
        
        # Save back to extra_data
        self.extra_data = json.dumps(extra_data)
        
        return True
    
    def __repr__(self):
        return f'<Episode {self.anime.title} - {self.number}>'

class WatchHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    anime_id = db.Column(db.Integer, db.ForeignKey('anime.id'), nullable=False)
    episode_id = db.Column(db.Integer, db.ForeignKey('episode.id'), nullable=False)
    watched_at = db.Column(db.DateTime, default=datetime.utcnow)
    position = db.Column(db.Integer, default=0)  # position in seconds
    completed = db.Column(db.Boolean, default=False)
    
    # Relationships
    user = db.relationship('User', back_populates='watch_history')
    episode = db.relationship('Episode', back_populates='watch_history')
    
    def __repr__(self):
        return f'<WatchHistory {self.user.username} - {self.episode.anime.title} Ep {self.episode.number}>'

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    anime_id = db.Column(db.Integer, db.ForeignKey('anime.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    upvotes = db.Column(db.Integer, default=0)
    downvotes = db.Column(db.Integer, default=0)
    
    # Relationships
    user = db.relationship('User', back_populates='comments')
    anime = db.relationship('Anime', back_populates='comments')
    
    def __repr__(self):
        return f'<Comment {self.id} by {self.user.username}>'

class Rating(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    anime_id = db.Column(db.Integer, db.ForeignKey('anime.id'), nullable=False)
    value = db.Column(db.Integer, nullable=False)  # 1 to 5
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', back_populates='ratings')
    anime = db.relationship('Anime', back_populates='ratings')
    
    __table_args__ = (
        db.UniqueConstraint('user_id', 'anime_id', name='user_anime_rating_uc'),
    )
    
    def __repr__(self):
        return f'<Rating {self.value} by {self.user.username} for {self.anime.title}>'
