"""
Migration script to add extra_data column to Episode table
"""
from app import app, db
import sqlite3

def add_extra_data_column():
    """Add extra_data column to Episode table if it doesn't exist"""
    try:
        with app.app_context():
            # Check if we're using SQLite
            if 'sqlite' in app.config['SQLALCHEMY_DATABASE_URI']:
                # SQLite doesn't support ALTER TABLE ADD COLUMN with constraints directly
                # Need to use raw SQL connection
                db_path = app.config['SQLALCHEMY_DATABASE_URI'].replace('sqlite:///', '')
                if not db_path:  # In-memory database
                    db_path = 'instance/database.db'
                
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                
                # Check if column exists
                cursor.execute("PRAGMA table_info(episode)")
                columns = [column[1] for column in cursor.fetchall()]
                
                if 'extra_data' not in columns:
                    print("Adding extra_data column to Episode table...")
                    cursor.execute("ALTER TABLE episode ADD COLUMN extra_data TEXT")
                    conn.commit()
                    print("Column added successfully!")
                else:
                    print("extra_data column already exists.")
                
                conn.close()
            else:
                # For other databases, use SQLAlchemy's reflection
                from sqlalchemy import Column, Text, MetaData, Table
                
                metadata = MetaData()
                metadata.reflect(bind=db.engine)
                episode_table = metadata.tables['episode']
                
                if 'extra_data' not in episode_table.c:
                    print("Adding extra_data column to Episode table...")
                    # Create a new column with desired properties
                    new_column = Column('extra_data', Text)
                    
                    # Add the column to the table
                    db.engine.execute('ALTER TABLE episode ADD COLUMN extra_data TEXT')
                    print("Column added successfully!")
                else:
                    print("extra_data column already exists.")
        
        return True
    except Exception as e:
        print(f"Error adding extra_data column: {e}")
        return False

if __name__ == "__main__":
    add_extra_data_column()