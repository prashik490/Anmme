from app import app, db
from models import User
from werkzeug.security import generate_password_hash

# Admin user credentials
admin_username = "Admin"
admin_email = "ingaleprashik490@gmail.com"
admin_password = "Pappu@120"

# Create admin user function
def create_admin_user():
    with app.app_context():
        # Check if the user already exists
        existing_user = User.query.filter(
            (User.username == admin_username) | (User.email == admin_email)
        ).first()
        
        if existing_user:
            # If user exists but is not admin, make them admin
            if not existing_user.is_admin:
                existing_user.is_admin = True
                db.session.commit()
                print(f"User {existing_user.username} is now an admin.")
            else:
                print(f"Admin user {existing_user.username} already exists.")
            return
        
        # Create new admin user
        new_admin = User(
            username=admin_username,
            email=admin_email,
            is_admin=True
        )
        new_admin.set_password(admin_password)
        
        # Add to database
        db.session.add(new_admin)
        db.session.commit()
        
        print(f"Admin user {admin_username} created successfully!")

if __name__ == "__main__":
    create_admin_user()