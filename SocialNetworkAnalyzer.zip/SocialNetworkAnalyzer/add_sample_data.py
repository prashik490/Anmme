from app import app, db
from models import Anime, Genre, Episode
from datetime import datetime, timedelta

# Sample data for genres
sample_genres = [
    {"name": "Action"},
    {"name": "Adventure"},
    {"name": "Comedy"},
    {"name": "Drama"},
    {"name": "Fantasy"},
    {"name": "Horror"},
    {"name": "Mystery"},
    {"name": "Romance"},
    {"name": "Sci-Fi"},
    {"name": "Slice of Life"},
    {"name": "Sports"}
]

# Sample data for anime
sample_anime = [
    {
        "title": "Demon Slayer",
        "alt_title": "Kimetsu no Yaiba",
        "synopsis": "Tanjiro Kamado sets out to become a demon slayer after his family is slaughtered and his sister is turned into a demon.",
        "cover_image": "https://m.media-amazon.com/images/M/MV5BZjZjNzI5MDctY2Y4YS00NmM4LTljMmItZTFkOTExNGI3ODRhXkEyXkFqcGdeQXVyNjc3MjQzNTI@._V1_.jpg",
        "banner_image": "https://cdn.oneesports.gg/cdn-data/2021/02/DemonSlayer_MugenTrain_LastScene.jpg",
        "release_year": 2019,
        "status": "ongoing",
        "genres": ["Action", "Fantasy", "Adventure"]
    },
    {
        "title": "My Hero Academia",
        "alt_title": "Boku no Hero Academia",
        "synopsis": "A superhero-loving boy without any powers is determined to enroll in a prestigious hero academy and learn what it really means to be a hero.",
        "cover_image": "https://m.media-amazon.com/images/M/MV5BOGZmYjdjN2UtNjAwZi00YmEyLWFhNTEtNjM1OTc5ODg0MGEyXkEyXkFqcGdeQXVyMTA1NjQyNjkw._V1_.jpg",
        "banner_image": "https://cdn.vox-cdn.com/thumbor/B-1rqc1QyPvcGt6Oc-EIq9c6zQw=/0x0:1280x720/1400x1050/filters:focal(538x258:742x462):no_upscale()/cdn.vox-cdn.com/uploads/chorus_image/image/70391185/maxresdefault.0.jpg",
        "release_year": 2016,
        "status": "ongoing",
        "genres": ["Action", "Comedy", "Sci-Fi"]
    },
    {
        "title": "Attack on Titan",
        "alt_title": "Shingeki no Kyojin",
        "synopsis": "After his hometown is destroyed and his mother is killed, young Eren Jaeger vows to cleanse the earth of the giant humanoid Titans that have brought humanity to the brink of extinction.",
        "cover_image": "https://flxt.tmsimg.com/assets/p10701949_b_v8_ah.jpg",
        "banner_image": "https://cdn.vox-cdn.com/thumbor/KYiGza0_v3NwXIex3yVcbFw4Aeg=/1400x1400/filters:format(jpeg)/cdn.vox-cdn.com/uploads/chorus_asset/file/22338971/attack_on_titan_season_4_1.jpg",
        "release_year": 2013,
        "status": "completed",
        "genres": ["Action", "Drama", "Fantasy", "Mystery"]
    },
    {
        "title": "Spy x Family",
        "alt_title": "SPY×FAMILY",
        "synopsis": "A spy on an undercover mission gets married and adopts a child as part of his cover. His wife and daughter have secrets of their own, and all three must strive to keep together.",
        "cover_image": "https://m.media-amazon.com/images/M/MV5BMWM4Njg2MjUtODU3OS00MGNmLWIyNTctZGJlODY4OGU1ZTk1XkEyXkFqcGdeQXVyMTMzNDExODE5._V1_.jpg",
        "banner_image": "https://animeshelter.com/wp-content/uploads/2022/04/Spy-x-Family.jpg",
        "release_year": 2022,
        "status": "ongoing",
        "genres": ["Action", "Comedy", "Slice of Life"]
    },
    {
        "title": "Jujutsu Kaisen",
        "alt_title": "呪術廻戦",
        "synopsis": "A boy swallows a cursed talisman - the finger of a demon - and becomes cursed himself. He enters a shaman school to be able to locate the demon's other body parts and thus exorcise himself.",
        "cover_image": "https://cdn.myanimelist.net/images/anime/1171/109222.jpg",
        "banner_image": "https://s.yimg.com/ny/api/res/1.2/9PJk5BDxwOFAZDiiHmCd4g--/YXBwaWQ9aGlnaGxhbmRlcjt3PTEyMDA7aD02NzU-/https://media.zenfs.com/en/comicbook.com/ccc4fb1acfbea7927bf47c66e87bf1d0",
        "release_year": 2020,
        "status": "ongoing",
        "genres": ["Action", "Fantasy", "Horror"]
    }
]

# Sample episode data (3 episodes per anime)
def create_sample_episodes(anime_id, title_prefix):
    today = datetime.utcnow().date()
    episodes = []
    
    for i in range(1, 4):
        episode = {
            "anime_id": anime_id,
            "title": f"{title_prefix} Episode {i}",
            "number": i,
            "video_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",  # Sample video
            "thumbnail": f"https://picsum.photos/seed/{anime_id}-{i}/640/360",  # Random placeholder image
            "duration": 1440,  # 24 minutes
            "release_date": today - timedelta(days=(3-i)*7),  # Weekly release
            "is_published": True
        }
        episodes.append(episode)
    
    return episodes

def add_sample_data():
    with app.app_context():
        # Check if data already exists
        if Genre.query.count() > 0 and Anime.query.count() > 0:
            print("Sample data already exists. Skipping...")
            return
        
        print("Adding sample data...")
        
        # Add genres
        genre_objects = {}
        for genre_data in sample_genres:
            # Check if genre already exists
            existing_genre = Genre.query.filter_by(name=genre_data["name"]).first()
            if not existing_genre:
                genre = Genre(name=genre_data["name"])
                db.session.add(genre)
                db.session.flush()  # Flush to get the ID
                genre_objects[genre_data["name"]] = genre
            else:
                genre_objects[genre_data["name"]] = existing_genre
        
        # Commit genres
        db.session.commit()
        print(f"Added {len(genre_objects)} genres")
        
        # Add anime
        anime_count = 0
        for anime_data in sample_anime:
            # Check if anime already exists
            existing_anime = Anime.query.filter_by(title=anime_data["title"]).first()
            if existing_anime:
                continue
                
            # Create new anime
            anime = Anime(
                title=anime_data["title"],
                alt_title=anime_data["alt_title"],
                synopsis=anime_data["synopsis"],
                cover_image=anime_data["cover_image"],
                banner_image=anime_data["banner_image"],
                release_year=anime_data["release_year"],
                status=anime_data["status"]
            )
            
            # Add genres
            for genre_name in anime_data["genres"]:
                if genre_name in genre_objects:
                    anime.genres.append(genre_objects[genre_name])
            
            db.session.add(anime)
            db.session.flush()  # Flush to get the ID
            
            # Add episodes
            episode_list = create_sample_episodes(anime.id, anime_data["title"])
            for episode_data in episode_list:
                episode = Episode(
                    anime_id=episode_data["anime_id"],
                    title=episode_data["title"],
                    number=episode_data["number"],
                    video_url=episode_data["video_url"],
                    thumbnail=episode_data["thumbnail"],
                    duration=episode_data["duration"],
                    release_date=episode_data["release_date"],
                    is_published=episode_data["is_published"]
                )
                db.session.add(episode)
            
            anime_count += 1
        
        # Commit all changes
        db.session.commit()
        print(f"Added {anime_count} anime with episodes")
        print("Sample data added successfully!")

if __name__ == "__main__":
    add_sample_data()